#ifndef PUSH_H
#define PUSH_H

#include "atom.h"
#include "point.h"
#include "genforce.h"
#include "ion.h"

void cfg_push (void);

#endif
