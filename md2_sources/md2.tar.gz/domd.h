/*
 * md series 2 (c) 1999 cameron abrams
 * 
 * domd.c: single-run driver
 */
#ifndef DOMD_H
#define DOMD_H

#include "cfg.h"
#include "args.h"
#include "push.h"

void do_md (int runId);

#endif
